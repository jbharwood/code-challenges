## Frontend Assessment - Work Orders

Created by Joseph Harwood
Portfolio: https://jbharwood.github.io

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.<br>
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.<br>
You will also see any lint errors in the console.

## Description

This app allows you to view work orders and see worker information on each work order. You can search for a worker by their full name and see what work orders they are working on. You can also sort the work orders by the deadline date.
