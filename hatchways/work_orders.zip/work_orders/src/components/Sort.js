import React from "react";

class Sort extends React.Component {

  state = {
    asc: false
  }

  handleToggle = () => {
    if (this.state.asc) {
      this.props.sort("asc")
    } else {
      this.props.sort("desc")
    }
    this.setState({asc: !this.state.asc})

  }

  render() {
    return (
      <div className="sort">
      <div className="sortText">Earliest first --- Latest first</div>
        <input
          checked={this.state.asc}
          onChange={this.handleToggle}
          className="react-switch-checkbox"
          id={`react-switch-new`}
          type="checkbox"
        />
        <label
          style={{ background: this.state.asc && '#06D6A0' }}
          className="react-switch-label"
          htmlFor={`react-switch-new`}
        >
          <span className={`react-switch-button`} />
        </label>
      </div>
    )
  }
}
export default Sort
